"""Қазақша дыбыс пен видеоны қайта жасау. Іске қосу: python tools/generate_narration.py
Қажет: pip install -r tools/requirements-narration.txt және PATH ішіндегі ffmpeg/ffprobe.
Жаңа файлдар generated-video/ ішінде пайда болады; түпнұсқалар өзгертілмейді.
"""
import asyncio
import json
import subprocess
from pathlib import Path
import edge_tts

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'generated-video'

def duration(path):
    return float(subprocess.check_output([
        'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
        '-of', 'csv=p=0', str(path)
    ]))

async def main():
    OUTPUT.mkdir(exist_ok=True)
    lessons = json.loads((ROOT / 'tools/narration.json').read_text(encoding='utf-8'))
    for lesson in lessons:
        audio = OUTPUT / (lesson['id'] + '.mp3')
        video = ROOT / 'dist/video' / (lesson['id'] + '.mp4')
        output = OUTPUT / (lesson['id'] + '.mp4')
        await edge_tts.Communicate(lesson['text'], 'kk-KZ-AigulNeural').save(str(audio))
        ratio = duration(audio) / duration(video)
        subprocess.run([
            'ffmpeg', '-y', '-i', str(video), '-i', str(audio),
            '-filter:v', f'setpts={ratio}*PTS', '-map', '0:v:0', '-map', '1:a:0',
            '-c:v', 'libx264', '-preset', 'fast', '-crf', '24',
            '-c:a', 'aac', '-b:a', '96k', '-movflags', '+faststart',
            '-shortest', str(output)
        ], check=True)
        print('Дайын:', output)

if __name__ == '__main__':
    asyncio.run(main())
