const fs=require('fs'),vm=require('vm'),assert=require('assert');
let context=vm.createContext({console});
vm.runInContext(fs.readFileSync('dist/practice-analysis.js','utf8')+';globalThis.analysis=practiceAnalysis',context);
const a=context.analysis;
assert.equal(a.analyze('', 'blend',2),null);
assert.equal(a.analyze('print(1)','py',0).scores.reduce((a,b)=>a+b),0);
const r=a.analyze('import bpy\nbpy.ops.mesh.primitive_cube_add()\nbpy.ops.mesh.primitive_uv_sphere_add()\nbpy.ops.mesh.primitive_cone_add()\nobject.scale=(1,2,3)\nmaterial = 1','py',2);
assert.equal(r.scores.reduce((a,b)=>a+b),100);
assert.equal(a.analyze('v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3','obj',2).scores.reduce((a,b)=>a+b),50);
// Render both roles, including old unreviewed submissions.
context=vm.createContext({db:{practiceSubmissions:[{id:'old',level:0,userId:'u',code:'print(1)',submittedAt:new Date().toISOString(),notes:'old'}],users:[{id:'u',name:'Test'}]},user:()=>({id:'u'}),esc:s=>String(s??''),heading:()=>'',stat:()=>'',empty:()=>'',practiceAnalysis:a});
vm.runInContext(fs.readFileSync('dist/practice.js','utf8')+';globalThis.p=practice;',context);
assert(context.p.studentPage().includes('Талдауға арналған код'));
assert(context.p.teacherPage().includes('data-review="old"'));
context.db.practiceSubmissions[0].review=r;
assert(context.p.teacherPage().includes('Кодты автоматты талдау'));
// Run the actual toggle handler twice and verify reversibility/persistence.
const app=fs.readFileSync('dist/app.js','utf8');
const handler=app.match(/if\(\$\('complete'\)\)\$\('complete'\).onclick=\(\)=>\{(.+?)\};/)[1];
const toggle=vm.createContext({db:{lessonProgress:[]},user:()=>({id:'u'}),id:'l',lesson:()=>({id:'l'}),save:()=>{},render:()=>{}});
vm.runInContext("const completed=l=>db.lessonProgress.some(p=>p.userId===user().id&&p.lessonId===l.id); function click(){"+handler+'}',toggle);
vm.runInContext('click()',toggle);assert.equal(toggle.db.lessonProgress.length,1);
vm.runInContext('click()',toggle);assert.equal(toggle.db.lessonProgress.length,0);
console.log('PASS: code analysis, unsupported files, student/teacher rendering, legacy submissions, reversible lesson progress');
