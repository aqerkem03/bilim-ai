const fs=require('fs'),vm=require('vm'),assert=require('assert');
const modules=fs.readFileSync('dist/3d.js','utf8'),data=fs.readFileSync('dist/data.js','utf8');
const prefix=fs.readFileSync('dist/app.js','utf8').split('const sessionKey')[0];
let saved;
const context=vm.createContext({document:{getElementById:()=>null},localStorage:{getItem:()=>saved||null,setItem:(k,v)=>saved=v},structuredClone});
vm.runInContext(data+'\n'+modules+'\n'+prefix+';globalThis.result=db',context);
let db=context.result,quiz=db.quizzes.find(q=>q.id==='bilimai-final-v1');
assert.equal(quiz.questions.length,17);assert.equal(db.quizzes.filter(q=>q.status==='published').length,1);assert.equal(db.attempts.length,2);
assert(quiz.questions.every(q=>q.options.length===4&&Number.isInteger(q.correct)&&q.correct<4));
assert.equal(new Set(quiz.questions.map(q=>q.id)).size,17);
assert(quiz.lessonIds.includes('l1'));assert(quiz.lessonIds.includes('3d-project'));
// Reload saved state: migration is idempotent and preserves original answer history.
const context2=vm.createContext({document:{getElementById:()=>null},localStorage:{getItem:()=>saved,setItem:()=>{}},structuredClone});
vm.runInContext(data+'\n'+modules+'\n'+prefix+';globalThis.result=db',context2);
assert.equal(context2.result.quizzes.length,db.quizzes.length);assert.equal(context2.result.attempts[0].answers[0].questionId,'q1');
vm.runInContext(fs.readFileSync('dist/tutor.js','utf8')+';globalThis.tutor=bilimTutor',context);
for(const [query,expected] of [['Extrude қалай қолданылады?','mesh'],['Mirror ортасы ашық қалды','modifiers'],['UV қалай ашылады?','materials'],['Кілттік кадр қалай қосылады?','animation'],['Камера көрінбейді','lighting'],['GLB экспорттау','project']]){
 const r=context.tutor.answer(query,'',null);assert.equal(r.module,expected,query);assert(r.steps.length>=4);
}
assert.equal(context.tutor.answer('Жұмыс істемейді','', 'mesh').module,'mesh');
assert.equal(context.tutor.answer('Сәлем','',null).title,'Сәлем!');
assert.equal(context.tutor.answer('Жаңа сұрақ','',null).module,null);
console.log('PASS: 17-question comprehensive test, migration/reload, old results, tutor topics and follow-up context');
