@echo off
cd /d "%~dp0"
py -3 -m http.server 8000 --bind 127.0.0.1 --directory dist
pause
