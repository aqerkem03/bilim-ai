# GitHub-қа қалай жүктеу керек?

## 1. Архивті шығару

ZIP-ті толық шығарыңыз. README.md және dist қалтасы қатар тұрған bilimAI қалтасын ашыңыз.
ZIP-тің өзін репозиторийге салудың орнына оның ішіндегі файлдарды салыңыз.
`dist` ішіндегі файлдардың атауын және орналасуын сақтаңыз.

## 2. Браузер арқылы жүктеу

1. GitHub аккаунтыңызға кіріңіз. Жаңа repository жасаңыз.
2. Атауы: `bilimai-graphics`. Public немесе Private таңдаңыз.
3. Create repository басыңыз.
4. Жаңа репозиторийде uploading an existing file немесе Add file → Upload files таңдаңыз.
5. bilimAI қалтасының ішіндегі README.md, README_KK.md, dist, docs, tests, tools,
   start-windows.bat, MANIFEST.sha256 файлдары мен қалталарын сүйреп апарыңыз.
   .gitignore жасырын тұрса, оны бөлек таңдаңыз немесе GitHub-та Create new file арқылы қосыңыз.
6. Commit changes өрісіне `Add bilimAI source and Kazakh documentation` жазыңыз және сақтаңыз.
7. Нәтижесінде репозиторий түбірінде README.md, ал dist ішінде index.html тұруы керек.

Бұл әрекеттерді қалталарды сүйреп жүктеу ыңғайлы болатын ноутбукта орындаңыз.

## 3. Git орнатылған болса

bilimAI қалтасында терминал ашыңыз. USERNAME орнына өз GitHub логиніңізді жазыңыз.
Бос GitHub репозиторийін алдын ала жасаңыз.

```bash
git init
git add .
git commit -m "Add bilimAI source and Kazakh documentation"
git branch -M main
git remote add origin https://github.com/USERNAME/bilimai-graphics.git
git push -u origin main
```

Git commit авторды сұраса, өз атыңыз бен GitHub email-іңізді git config арқылы орнатыңыз.
GitHub авторизациясын браузер немесе Git Credential Manager арқылы орындаңыз.
Токенді кодқа, README-ге немесе remote URL-ге жазбаңыз.

## 4. GitHub Pages арқылы жариялау

Жобаға `.github/workflows/pages.yml` дайын қосылған. Public репозиторийде:

1. Settings → Pages ашыңыз.
2. Build and deployment → Source ретінде GitHub Actions таңдаңыз.
3. Actions бөлімінен Deploy static site жұмысын Run workflow арқылы орындаңыз.
4. Жұмыс сәтті аяқталған соң Pages бөлімінде сайттың мекенжайы көрсетіледі.

Workflow тек `dist/` файлдарын жариялайды, сондықтан README мен құралдар сайтқа қосылмайды.
main тармағына келесі push жасалғанда сайт қайта жарияланады.
Жариялау бастапқы ChatGPT сайтты өзгертпейді. Екі мекенжай браузер деректерін бөліспейді.
GitHub Pages серверлік C# кодын немесе дерекқорды іске қоспайды.

## 5. Қай файлды өзгертемін?

| Мақсат | Файл |
| --- | --- |
| Түстер, өлшемдер, кіру бетінің дизайны | dist/style.css |
| Кіру және тіркелу мәтіні | dist/portal.js |
| Беттер, тесттер, нәтижелер | dist/app.js |
| 3D сабақ мазмұны | dist/3d.js |
| Бастапқы демо деректер | dist/data.js |
| Балл есептеу, сұрақ ұсыну | dist/domain.js |
| Практика интерфейсі | dist/practice.js |
| Файл сақтау және ережелік талдау | dist/practice-analysis.js |
| Көмекші жауаптары | dist/tutor.js |
| SQL құрылымының үлгісі | dist/schema.sql |

Толық түсіндірме: KOD_TUSINDIRME_KK.md. Өңдеуден кейін бетті жаңартып тексеріңіз.
